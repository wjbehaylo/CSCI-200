#ifndef ISOCELESTRIANGLE_H
#define ISOCELESTRIANGLE_H

#include "Triangle.h"
#include <SFML/Graphics.hpp>
using namespace sf;

#include <cmath> //for length calculations
#include <iostream>
using namespace std;

//documentation of isoceles triangle class

class IsocelesTriangle: public Triangle{
    public:
        /**
        * @brief overload of setCoordinates function from Triangle abstract class, if the points create non-zero, triangular sides, return true and make them the values in xyCoords, otherwise return false
        * @param x1 this is the x coordinate of the first point
        * @param y1 this is the y coordinate of the first point
        * @param x2 x coordinate of second point
        * @param y2 y coordinate of second point
        * @param x3 x coordinate of third point
        * @param y3 y coordinate of third point
        * @return returns true if the three sides form a triangle and at least 2 of the three sides are equal
        */
        bool setCoordinates(const double x1, const double y1, const double x2, const double y2, const double x3, const double y3) override; 

};

#endif